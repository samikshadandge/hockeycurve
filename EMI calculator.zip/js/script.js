function calculateEMI() {
  const principal = parseFloat(document.getElementById('principal').value);
  const annualRate = parseFloat(document.getElementById('rate').value);
  const months = parseInt(document.getElementById('months').value);

  if (isNaN(principal) || isNaN(annualRate) || isNaN(months) || principal <= 0 || annualRate <= 0 || months <= 0) {
    document.getElementById('emi-result').textContent = "Please enter valid inputs";
    return;
  }

  const monthlyRate = annualRate / 12 / 100;
  const emi = (principal * monthlyRate * Math.pow(1 + monthlyRate, months)) / (Math.pow(1 + monthlyRate, months) - 1);

  document.getElementById('emi-result').textContent = `EMI: ₹${emi.toFixed(2)}`;
}
